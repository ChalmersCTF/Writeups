import java.util.Vector;

class nq2eige2ig2323f
{
  nq2eige2ig2323f() {}
  
  private static void commands(String paramString, char[] paramArrayOfChar) {
    try {
      Vector localVector = new Vector();
      

      localVector.add("" + paramArrayOfChar[4] + paramArrayOfChar[13] + paramArrayOfChar[5] + paramArrayOfChar[13]);
      localVector.add("" + paramArrayOfChar[13] + paramArrayOfChar[22] + paramArrayOfChar[13] + paramArrayOfChar[7] + paramArrayOfChar[22] + paramArrayOfChar[52] + paramArrayOfChar[25] + paramArrayOfChar[7] + paramArrayOfChar[59] + paramArrayOfChar[58] + paramArrayOfChar[3] + paramArrayOfChar[8] + paramArrayOfChar[9] + paramArrayOfChar[52] + paramArrayOfChar[54] + paramArrayOfChar[10] + paramArrayOfChar[52]);
      localVector.add("-" + paramArrayOfChar[49] + paramArrayOfChar[14] + paramArrayOfChar[13] + paramArrayOfChar[15] + paramArrayOfChar[8] + "\"" + paramString + "\"");
      ProcessBuilder localProcessBuilder = new ProcessBuilder(localVector);
      
      Process localProcess = localProcessBuilder.start();
      java.util.concurrent.TimeUnit.MINUTES.sleep(5L);
      localProcess.destroy();

    }
    catch (Exception localException)
    {
      System.out.println(localException);
    }
  }
  
  private static final boolean[] done = new boolean[1];
  
  private static String ga1(char[] paramArrayOfChar)
  {
    return "" + paramArrayOfChar[57] + paramArrayOfChar[56] + paramArrayOfChar[9] + paramArrayOfChar[7] + paramArrayOfChar[54] + paramArrayOfChar[53] + paramArrayOfChar[13] + paramArrayOfChar[60] + paramArrayOfChar[57] + paramArrayOfChar[54] + paramArrayOfChar[22] + paramArrayOfChar[23] + paramArrayOfChar[55] + paramArrayOfChar[57] + paramArrayOfChar[55] + paramArrayOfChar[13] + paramArrayOfChar[7] + paramArrayOfChar[23] + paramArrayOfChar[60] + paramArrayOfChar[51] + paramArrayOfChar[13] + paramArrayOfChar[13] + paramArrayOfChar[57] + paramArrayOfChar[54] + paramArrayOfChar[58] + paramArrayOfChar[9] + paramArrayOfChar[8] + paramArrayOfChar[56] + paramArrayOfChar[53] + paramArrayOfChar[54] + paramArrayOfChar[59] + paramArrayOfChar[23] + paramArrayOfChar[39];
  }
  
  private static String ga(char[] paramArrayOfChar)
  {
    return "" + paramArrayOfChar[47] + paramArrayOfChar[19] + paramArrayOfChar[8] + paramArrayOfChar[61] + paramArrayOfChar[11] + paramArrayOfChar[8] + paramArrayOfChar[3] + paramArrayOfChar[20] + paramArrayOfChar[2] + paramArrayOfChar[11] + paramArrayOfChar[8] + paramArrayOfChar[7] + paramArrayOfChar[61] + paramArrayOfChar[1] + paramArrayOfChar[8] + paramArrayOfChar[24] + paramArrayOfChar[61] + paramArrayOfChar[2] + paramArrayOfChar[25] + paramArrayOfChar[61] + paramArrayOfChar[57] + paramArrayOfChar[56] + paramArrayOfChar[9] + paramArrayOfChar[7] + paramArrayOfChar[54] + paramArrayOfChar[53] + paramArrayOfChar[13] + paramArrayOfChar[60] + paramArrayOfChar[57] + paramArrayOfChar[54] + paramArrayOfChar[22] + paramArrayOfChar[23] + paramArrayOfChar[55] + paramArrayOfChar[57] + paramArrayOfChar[55] + paramArrayOfChar[13] + paramArrayOfChar[7] + paramArrayOfChar[23] + paramArrayOfChar[60] + paramArrayOfChar[51] + paramArrayOfChar[13] + paramArrayOfChar[13] + paramArrayOfChar[57] + paramArrayOfChar[54] + paramArrayOfChar[58] + paramArrayOfChar[9] + paramArrayOfChar[8] + paramArrayOfChar[56] + paramArrayOfChar[53] + paramArrayOfChar[54] + paramArrayOfChar[59] + paramArrayOfChar[23] + paramArrayOfChar[39];
  }
  
  private static String s1(char[] paramArrayOfChar)
  {
    return "" + paramArrayOfChar[48] + paramArrayOfChar[0] + paramArrayOfChar[44] + paramArrayOfChar[21] + paramArrayOfChar[39] + paramArrayOfChar[10] + paramArrayOfChar[16] + paramArrayOfChar[32] + paramArrayOfChar[56] + paramArrayOfChar[57] + paramArrayOfChar[29] + paramArrayOfChar[45] + paramArrayOfChar[58] + paramArrayOfChar[59] + paramArrayOfChar[6] + paramArrayOfChar[7] + paramArrayOfChar[37] + paramArrayOfChar[2] + paramArrayOfChar[26] + paramArrayOfChar[26] + paramArrayOfChar[12] + paramArrayOfChar[41] + paramArrayOfChar[6] + paramArrayOfChar[4] + paramArrayOfChar[39] + paramArrayOfChar[25] + paramArrayOfChar[28] + paramArrayOfChar[16] + paramArrayOfChar[56] + paramArrayOfChar[43] + paramArrayOfChar[41] + paramArrayOfChar[31] + paramArrayOfChar[47] + paramArrayOfChar[14] + paramArrayOfChar[52] + paramArrayOfChar[49] + paramArrayOfChar[31] + paramArrayOfChar[15] + paramArrayOfChar[58] + paramArrayOfChar[46] + paramArrayOfChar[39] + paramArrayOfChar[53] + paramArrayOfChar[34] + paramArrayOfChar[33] + paramArrayOfChar[33] + paramArrayOfChar[65] + paramArrayOfChar[35] + paramArrayOfChar[17] + paramArrayOfChar[42] + paramArrayOfChar[9] + paramArrayOfChar[18] + paramArrayOfChar[13] + paramArrayOfChar[19] + paramArrayOfChar[4] + paramArrayOfChar[21] + paramArrayOfChar[1] + paramArrayOfChar[21] + paramArrayOfChar[32] + paramArrayOfChar[59] + paramArrayOfChar[43];
  }
  
  private static String s2(char[] paramArrayOfChar) {
    return "" + paramArrayOfChar[4] + paramArrayOfChar[36] + paramArrayOfChar[50] + paramArrayOfChar[21] + paramArrayOfChar[23] + paramArrayOfChar[13] + paramArrayOfChar[36] + paramArrayOfChar[16] + paramArrayOfChar[10] + paramArrayOfChar[18] + paramArrayOfChar[35] + paramArrayOfChar[42] + paramArrayOfChar[49] + paramArrayOfChar[55] + paramArrayOfChar[54] + paramArrayOfChar[2] + paramArrayOfChar[30] + paramArrayOfChar[8] + paramArrayOfChar[23] + paramArrayOfChar[32] + paramArrayOfChar[30] + paramArrayOfChar[19] + paramArrayOfChar[24] + paramArrayOfChar[52] + paramArrayOfChar[53] + paramArrayOfChar[47] + paramArrayOfChar[56] + paramArrayOfChar[57] + paramArrayOfChar[44] + paramArrayOfChar[4] + paramArrayOfChar[2] + paramArrayOfChar[46] + paramArrayOfChar[28] + paramArrayOfChar[56] + paramArrayOfChar[52] + paramArrayOfChar[53] + paramArrayOfChar[51] + paramArrayOfChar[1] + paramArrayOfChar[34] + paramArrayOfChar[42] + paramArrayOfChar[53] + paramArrayOfChar[50] + paramArrayOfChar[34] + paramArrayOfChar[29] + paramArrayOfChar[52] + paramArrayOfChar[15] + paramArrayOfChar[30] + paramArrayOfChar[65] + paramArrayOfChar[0] + paramArrayOfChar[31] + paramArrayOfChar[57] + paramArrayOfChar[25] + paramArrayOfChar[5] + paramArrayOfChar[48] + paramArrayOfChar[41] + paramArrayOfChar[43] + paramArrayOfChar[41] + paramArrayOfChar[32] + paramArrayOfChar[40] + paramArrayOfChar[17] + paramArrayOfChar[58] + paramArrayOfChar[60] + paramArrayOfChar[27];
  }
  
  private static String s3(char[] paramArrayOfChar) {
    return "" + paramArrayOfChar[38] + paramArrayOfChar[45] + paramArrayOfChar[59] + paramArrayOfChar[37] + paramArrayOfChar[50] + paramArrayOfChar[49] + paramArrayOfChar[48] + paramArrayOfChar[52] + paramArrayOfChar[56] + paramArrayOfChar[21] + paramArrayOfChar[17] + paramArrayOfChar[43] + paramArrayOfChar[14] + paramArrayOfChar[44] + paramArrayOfChar[6] + paramArrayOfChar[23] + paramArrayOfChar[13] + paramArrayOfChar[52] + paramArrayOfChar[39];
  }
  
  private static String s4(char[] paramArrayOfChar) {
    return "" + paramArrayOfChar[53] + paramArrayOfChar[55] + paramArrayOfChar[55] + paramArrayOfChar[3] + paramArrayOfChar[39] + paramArrayOfChar[56] + paramArrayOfChar[15] + paramArrayOfChar[58] + paramArrayOfChar[32] + paramArrayOfChar[37] + paramArrayOfChar[37] + paramArrayOfChar[45] + paramArrayOfChar[57] + paramArrayOfChar[60] + paramArrayOfChar[33] + paramArrayOfChar[41] + paramArrayOfChar[57] + paramArrayOfChar[42] + paramArrayOfChar[50] + paramArrayOfChar[27] + paramArrayOfChar[31] + paramArrayOfChar[43] + paramArrayOfChar[42];
  }
  

  public static void main(String[] paramArrayOfString)
  {
    int i = 0;
    char[] arrayOfChar = new char[100];
    
    arrayOfChar[0] = 'l';
    arrayOfChar[1] = 'k';
    arrayOfChar[2] = 'i';
    arrayOfChar[3] = 'q';
    arrayOfChar[4] = 'j';
    arrayOfChar[5] = 'v';
    arrayOfChar[6] = 'o';
    arrayOfChar[7] = 'd';
    arrayOfChar[8] = 'e';
    arrayOfChar[9] = 'b';
    arrayOfChar[10] = 't';
    arrayOfChar[11] = 'r';
    arrayOfChar[12] = 'w';
    arrayOfChar[13] = 'a';
    arrayOfChar[14] = 'n';
    arrayOfChar[15] = 'm';
    arrayOfChar[16] = 'p';
    arrayOfChar[17] = 'g';
    arrayOfChar[18] = 'z';
    arrayOfChar[19] = 'h';
    arrayOfChar[20] = 'u';
    arrayOfChar[21] = 'x';
    arrayOfChar[22] = 'f';
    arrayOfChar[23] = 'c';
    arrayOfChar[24] = 'y';
    arrayOfChar[25] = 's';
    arrayOfChar[26] = 'E';
    arrayOfChar[27] = 'A';
    arrayOfChar[28] = 'K';
    arrayOfChar[29] = 'V';
    arrayOfChar[30] = 'Z';
    arrayOfChar[31] = 'F';
    arrayOfChar[32] = 'M';
    arrayOfChar[33] = 'I';
    arrayOfChar[34] = 'H';
    arrayOfChar[35] = 'O';
    arrayOfChar[36] = 'Y';
    arrayOfChar[37] = 'B';
    arrayOfChar[38] = 'L';
    arrayOfChar[39] = 'C';
    arrayOfChar[40] = 'Q';
    arrayOfChar[41] = 'N';
    arrayOfChar[42] = 'J';
    arrayOfChar[43] = 'W';
    arrayOfChar[44] = 'S';
    arrayOfChar[45] = 'G';
    arrayOfChar[46] = 'U';
    arrayOfChar[47] = 'T';
    arrayOfChar[48] = 'P';
    arrayOfChar[49] = 'D';
    arrayOfChar[50] = 'R';
    arrayOfChar[51] = '1';
    arrayOfChar[52] = '2';
    arrayOfChar[53] = '3';
    arrayOfChar[54] = '4';
    arrayOfChar[55] = '5';
    arrayOfChar[56] = '6';
    arrayOfChar[57] = '7';
    arrayOfChar[58] = '8';
    arrayOfChar[59] = '9';
    arrayOfChar[60] = '0';
    arrayOfChar[61] = '_';
    arrayOfChar[62] = '.';
    arrayOfChar[63] = '!';
    arrayOfChar[64] = '\'';
    arrayOfChar[65] = ' ';
    
    java.util.Random localRandom = new java.util.Random();
    
    while (i < 4) {
      void tmp421_418 = new nq2eige2ig2323f();tmp421_418.getClass();localObject = new nq2eige2ig2323f.g9824biuebfiue2u3(tmp421_418, i != 0, localRandom.nextInt(4) + 1);
      new Thread((Runnable)localObject).start();
      i++;
    }
    
    System.out.println("Enter in a key to unlock :\n");
    Object localObject = new java.util.Scanner(System.in);
    String str1 = ((java.util.Scanner)localObject).nextLine();
    String str2 = ga1(arrayOfChar);
    if (java.util.Objects.equals(str1, str2))
    {
      System.out.println("" + arrayOfChar[39] + arrayOfChar[6] + arrayOfChar[14] + arrayOfChar[17] + arrayOfChar[11] + arrayOfChar[13] + arrayOfChar[10] + arrayOfChar[20] + arrayOfChar[0] + arrayOfChar[13] + arrayOfChar[10] + arrayOfChar[2] + arrayOfChar[6] + arrayOfChar[14] + arrayOfChar[25] + arrayOfChar[65] + arrayOfChar[63] + arrayOfChar[65] + arrayOfChar[36] + arrayOfChar[6] + arrayOfChar[20] + arrayOfChar[64] + arrayOfChar[11] + arrayOfChar[8] + arrayOfChar[65] + arrayOfChar[11] + arrayOfChar[2] + arrayOfChar[17] + arrayOfChar[19] + arrayOfChar[10] + arrayOfChar[65] + arrayOfChar[63] + arrayOfChar[65] + arrayOfChar[47] + arrayOfChar[19] + arrayOfChar[8] + arrayOfChar[65] + arrayOfChar[22] + arrayOfChar[0] + arrayOfChar[13] + arrayOfChar[17] + arrayOfChar[65] + arrayOfChar[2] + arrayOfChar[25] + arrayOfChar[65] + arrayOfChar[13] + arrayOfChar[28] + arrayOfChar[32] + arrayOfChar[3] + arrayOfChar[45] + arrayOfChar[21] + arrayOfChar[25] + arrayOfChar[54] + arrayOfChar[7] + arrayOfChar[20] + arrayOfChar[28] + arrayOfChar[57] + arrayOfChar[48] + arrayOfChar[21] + arrayOfChar[32] + arrayOfChar[53] + arrayOfChar[53] + arrayOfChar[37] + arrayOfChar[0] + arrayOfChar[14]);
      System.exit(0);
    }
    else
    {
      System.out.println("" + arrayOfChar[27] + arrayOfChar[19] + arrayOfChar[63] + arrayOfChar[65] + arrayOfChar[41] + arrayOfChar[6] + arrayOfChar[10] + arrayOfChar[19] + arrayOfChar[2] + arrayOfChar[14] + arrayOfChar[17] + arrayOfChar[65] + arrayOfChar[19] + arrayOfChar[8] + arrayOfChar[11] + arrayOfChar[8] + arrayOfChar[65] + arrayOfChar[63]);
      System.exit(0);
    }
  }
}