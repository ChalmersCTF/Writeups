import java.util.concurrent.TimeUnit;

class afadf2sd98qeb24t2 {
  afadf2sd98qeb24t2() {}
  
  public static void main(String[] paramArrayOfString) {
    try {
      TimeUnit.MINUTES.sleep(5L);
      System.exit(0);
    }
    catch (Exception localException) {}
  }
}